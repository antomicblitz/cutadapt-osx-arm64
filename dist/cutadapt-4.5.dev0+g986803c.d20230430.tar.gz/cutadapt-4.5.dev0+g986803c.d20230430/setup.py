from setuptools import setup, Extension
import setuptools_scm  # noqa  Ensure it’s installed

extensions = [
    Extension("cutadapt._align", sources=["src/cutadapt/_align.pyx"], extra_compile_args=["-Ofast", "-march=native"]),
    Extension("cutadapt.qualtrim", sources=["src/cutadapt/qualtrim.pyx"], extra_compile_args=["-Ofast", "-march=native"]),
    Extension("cutadapt.info", sources=["src/cutadapt/info.pyx"], extra_compile_args=["-Ofast", "-march=native"]),
    Extension("cutadapt._kmer_finder", sources=["src/cutadapt/_kmer_finder.pyx"], extra_compile_args=["-Ofast", "-march=native"]),
]

setup(ext_modules=extensions)
