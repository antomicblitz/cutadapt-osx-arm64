import sys
from cutadapt.cli import main_cli

if __name__ == "__main__":
    sys.exit(main_cli())
